
<?php


if($_POST["message"]) {


mail("shivaranjan.dodavad@gmail.com", "Here is the subject line",


$_POST["insert your message here"]. "From: shivaranjan.dodavad@gmail.com");


}


?>